# demo-video-vast

Desktop version: https://jtorresdev.github.io/demo-video-vast/strangerthings

Mobile version: https://jtorresdev.github.io/demo-video-vast/strangerthings/mobile
